﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Materials
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtIdMaterials = New System.Windows.Forms.TextBox()
        Me.txtVendor = New System.Windows.Forms.TextBox()
        Me.txtMsize = New System.Windows.Forms.TextBox()
        Me.txtMtype = New System.Windows.Forms.TextBox()
        Me.txtMthickness = New System.Windows.Forms.TextBox()
        Me.txtMprize = New System.Windows.Forms.TextBox()
        Me.txtMdesc = New System.Windows.Forms.TextBox()
        Me.txtClass = New System.Windows.Forms.TextBox()
        Me.txtElbowType = New System.Windows.Forms.TextBox()
        Me.txtElbowThinckness = New System.Windows.Forms.TextBox()
        Me.txtElbowPrize = New System.Windows.Forms.TextBox()
        Me.txtElbowDesc = New System.Windows.Forms.TextBox()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnQuery = New System.Windows.Forms.Button()
        Me.btnMenu = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnQuery)
        Me.GroupBox1.Controls.Add(Me.btnSave)
        Me.GroupBox1.Controls.Add(Me.txtElbowDesc)
        Me.GroupBox1.Controls.Add(Me.txtElbowPrize)
        Me.GroupBox1.Controls.Add(Me.txtElbowThinckness)
        Me.GroupBox1.Controls.Add(Me.txtElbowType)
        Me.GroupBox1.Controls.Add(Me.txtClass)
        Me.GroupBox1.Controls.Add(Me.txtMdesc)
        Me.GroupBox1.Controls.Add(Me.txtMprize)
        Me.GroupBox1.Controls.Add(Me.txtMthickness)
        Me.GroupBox1.Controls.Add(Me.txtMtype)
        Me.GroupBox1.Controls.Add(Me.txtMsize)
        Me.GroupBox1.Controls.Add(Me.txtVendor)
        Me.GroupBox1.Controls.Add(Me.txtIdMaterials)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 62)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1154, 382)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "GroupBox1"
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(8, 450)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 62
        Me.DataGridView1.RowTemplate.Height = 28
        Me.DataGridView1.Size = New System.Drawing.Size(1154, 246)
        Me.DataGridView1.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(29, 39)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(87, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "IdMaterials"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(29, 92)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 20)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Vendor"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(29, 132)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 20)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "MSize"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(29, 180)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(56, 20)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "MType"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(29, 234)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(93, 20)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "MThickness"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(29, 287)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(57, 20)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "MPrize"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(508, 39)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(59, 20)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "MDesc"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(508, 92)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(48, 20)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Class"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(508, 132)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(86, 20)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "ElbowType"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(508, 180)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(123, 20)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "ElbowThickness"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(508, 234)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(87, 20)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "ElbowPrize"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(508, 287)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(89, 20)
        Me.Label12.TabIndex = 11
        Me.Label12.Text = "ElbowDesc"
        '
        'txtIdMaterials
        '
        Me.txtIdMaterials.Location = New System.Drawing.Point(122, 36)
        Me.txtIdMaterials.Name = "txtIdMaterials"
        Me.txtIdMaterials.Size = New System.Drawing.Size(143, 26)
        Me.txtIdMaterials.TabIndex = 12
        '
        'txtVendor
        '
        Me.txtVendor.Location = New System.Drawing.Point(96, 86)
        Me.txtVendor.Name = "txtVendor"
        Me.txtVendor.Size = New System.Drawing.Size(169, 26)
        Me.txtVendor.TabIndex = 13
        '
        'txtMsize
        '
        Me.txtMsize.Location = New System.Drawing.Point(88, 126)
        Me.txtMsize.Name = "txtMsize"
        Me.txtMsize.Size = New System.Drawing.Size(177, 26)
        Me.txtMsize.TabIndex = 14
        '
        'txtMtype
        '
        Me.txtMtype.Location = New System.Drawing.Point(91, 174)
        Me.txtMtype.Name = "txtMtype"
        Me.txtMtype.Size = New System.Drawing.Size(174, 26)
        Me.txtMtype.TabIndex = 15
        '
        'txtMthickness
        '
        Me.txtMthickness.Location = New System.Drawing.Point(128, 228)
        Me.txtMthickness.Name = "txtMthickness"
        Me.txtMthickness.Size = New System.Drawing.Size(161, 26)
        Me.txtMthickness.TabIndex = 16
        '
        'txtMprize
        '
        Me.txtMprize.Location = New System.Drawing.Point(92, 281)
        Me.txtMprize.Name = "txtMprize"
        Me.txtMprize.Size = New System.Drawing.Size(173, 26)
        Me.txtMprize.TabIndex = 17
        '
        'txtMdesc
        '
        Me.txtMdesc.Location = New System.Drawing.Point(573, 33)
        Me.txtMdesc.Name = "txtMdesc"
        Me.txtMdesc.Size = New System.Drawing.Size(180, 26)
        Me.txtMdesc.TabIndex = 18
        '
        'txtClass
        '
        Me.txtClass.Location = New System.Drawing.Point(562, 89)
        Me.txtClass.Name = "txtClass"
        Me.txtClass.Size = New System.Drawing.Size(191, 26)
        Me.txtClass.TabIndex = 19
        '
        'txtElbowType
        '
        Me.txtElbowType.Location = New System.Drawing.Point(600, 129)
        Me.txtElbowType.Name = "txtElbowType"
        Me.txtElbowType.Size = New System.Drawing.Size(202, 26)
        Me.txtElbowType.TabIndex = 20
        '
        'txtElbowThinckness
        '
        Me.txtElbowThinckness.Location = New System.Drawing.Point(637, 177)
        Me.txtElbowThinckness.Name = "txtElbowThinckness"
        Me.txtElbowThinckness.Size = New System.Drawing.Size(184, 26)
        Me.txtElbowThinckness.TabIndex = 21
        '
        'txtElbowPrize
        '
        Me.txtElbowPrize.Location = New System.Drawing.Point(601, 231)
        Me.txtElbowPrize.Name = "txtElbowPrize"
        Me.txtElbowPrize.Size = New System.Drawing.Size(181, 26)
        Me.txtElbowPrize.TabIndex = 22
        '
        'txtElbowDesc
        '
        Me.txtElbowDesc.Location = New System.Drawing.Point(603, 284)
        Me.txtElbowDesc.Name = "txtElbowDesc"
        Me.txtElbowDesc.Size = New System.Drawing.Size(179, 26)
        Me.txtElbowDesc.TabIndex = 23
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(871, 72)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(100, 40)
        Me.btnSave.TabIndex = 24
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnQuery
        '
        Me.btnQuery.Location = New System.Drawing.Point(1012, 72)
        Me.btnQuery.Name = "btnQuery"
        Me.btnQuery.Size = New System.Drawing.Size(85, 40)
        Me.btnQuery.TabIndex = 25
        Me.btnQuery.Text = "Query"
        Me.btnQuery.UseVisualStyleBackColor = True
        '
        'btnMenu
        '
        Me.btnMenu.Location = New System.Drawing.Point(23, 12)
        Me.btnMenu.Name = "btnMenu"
        Me.btnMenu.Size = New System.Drawing.Size(101, 32)
        Me.btnMenu.TabIndex = 2
        Me.btnMenu.Text = "Menu"
        Me.btnMenu.UseVisualStyleBackColor = True
        '
        'Materials
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1174, 708)
        Me.Controls.Add(Me.btnMenu)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Materials"
        Me.Text = "Materials"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnQuery As Button
    Friend WithEvents btnSave As Button
    Friend WithEvents txtElbowDesc As TextBox
    Friend WithEvents txtElbowPrize As TextBox
    Friend WithEvents txtElbowThinckness As TextBox
    Friend WithEvents txtElbowType As TextBox
    Friend WithEvents txtClass As TextBox
    Friend WithEvents txtMdesc As TextBox
    Friend WithEvents txtMprize As TextBox
    Friend WithEvents txtMthickness As TextBox
    Friend WithEvents txtMtype As TextBox
    Friend WithEvents txtMsize As TextBox
    Friend WithEvents txtVendor As TextBox
    Friend WithEvents txtIdMaterials As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btnMenu As Button
End Class
